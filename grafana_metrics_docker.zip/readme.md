API KEY grafana= glsa_N9zhPQlGkEkvsyatuqTyeFxNdGvQEM4V_f6a5c8e7

curl -X POST --insecure -H "Authorization: Bearer glsa_N9zhPQlGkEkvsyatuqTyeFxNdGvQEM4V_f6a5c8e7" -H "Content-Type: application/json" -d "{\"dashboard\":$(cat docker-quest-prometheus.json)}" http://localhost:3000/api/dashboards/db



curl --insecure  -H "Authorization: Bearer glsa_N9zhPQlGkEkvsyatuqTyeFxNdGvQEM4V_f6a5c8e7"  http://localhost:3000/api/datasources 
